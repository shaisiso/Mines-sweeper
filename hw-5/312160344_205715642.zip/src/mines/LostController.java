package mines;

import javafx.fxml.FXML;
import javafx.scene.image.ImageView;

public class LostController {

    @FXML
    private ImageView im1;

    @FXML
    private ImageView im2;

    @FXML
    private ImageView im3;

    @FXML
    private ImageView im4;

}
